// main_test.go (Assuming SendCustomerEmail is in a package named 'email')
package main

import (
	"testing"

	mocks "github.com/akv/mck5/mocks" // Replace with your actual module path for mocks
	"github.com/golang/mock/gomock"   // Replace with your actual module path
)

func TestSendCustomerEmail(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	mockEmailSender := mocks.NewMockEmailSender(ctrl)

	mockEmailSender.EXPECT().SendEmail("customer@example.com", "Welcome to My App!", "Thank you for signing up for our service.").Return(nil)

	// Assuming SendCustomerEmail is now part of the 'email' package
	if err := SendCustomerEmail(mockEmailSender, "customer@example.com"); err != nil {
		t.Errorf("Failed to send customer email: %v", err)
	}
}
